/*
CleanShot X Functions
- https://cleanshot.com/docs/api
*/

function run() {
  LaunchBar.openURL('cleanshot://open-history');
}

/*
// General LaunchBar function calls listed below for reference:
function doStuff(actionArgument) {
  LaunchBar.hide();
  LaunchBar.executeAppleScript('delay 0.1');
  LaunchBar.openURL(actionArgument);
}
*/