// Convert text to "smart title case"'", ignoring "small words" and preserving
// words in all caps, etc.
//
// JavaScript © 2018 David Gouch, https://github.com/gouch/to-title-case
// from an original perl script by John Gruber –
// https://daringfireball.net/2008/08/title_case_update
//
// Converted to a LaunchBar Action by Charles Butcher 2023-06-17.
//
// John Gruber's list of "small words" that are not capped came from the
// New York Times Manual of Style, to which he added 'vs' and 'v'.
// Later additions by Charles Butcher are 'mm', 'cm' and 'm'.
//
// 2024-03-19 Charles Butcher version 1.1 – updated to change all-caps
// headings to lowercase before further processing.

function run(argument) {
    if (argument == undefined) {
        // Inform the user that there was no argument
        LaunchBar.alert('No argument was passed to the action');
    } else {
        LaunchBar.paste(toTitleCase(argument));
//        return [{ title : toTitleCase(argument) }];
    }
}

function toTitleCase(str) {
  'use strict'
  var smallWords = /^(a|an|and|as|at|but|by|en|for|if|in|nor|of|on|or|per|the|to|v.?|vs.?|via)$/i
  var alphanumericPattern = /([A-Za-z0-9\u00C0-\u00FF])/
  var wordSeparators = /([ :–—-])/

  // This function preserves words such as acronyms that are all uppercase.
  // That is normally useful, but it's not much good if _all_ the text is in
  // uppercase, so we convert all-caps headings to lowercase first. Acronyms
  // etc. will be lost, but that can't be helped.

  if (str === str.toUpperCase()) {
    str = str.toLowerCase();
  }

  return str.split(wordSeparators)
    .map(function (current, index, array) {
      if (
        /* Check for small words */
        current.search(smallWords) > -1 &&
        /* Skip first and last word */
        index !== 0 &&
        index !== array.length - 1 &&
        /* Ignore title end and subtitle start */
        array[index - 3] !== ':' &&
        array[index + 1] !== ':' &&
        /* Ignore small words that start a hyphenated phrase */
        (array[index + 1] !== '-' ||
          (array[index - 1] === '-' && array[index + 1] === '-'))
      ) {
        return current.toLowerCase()
      }

      /* Ignore intentional capitalization */
      if (current.substr(1).search(/[A-Z]|\../) > -1) {
        return current
      }

      /* Ignore URLs */
      if (array[index + 1] === ':' && array[index + 2] !== '') {
        return current
      }

      /* Capitalize the first letter */
      return current.replace(alphanumericPattern, function (match) {
        return match.toUpperCase()
      })
    })
    .join('')
}
